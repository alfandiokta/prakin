<?php
class Absensi_model extends CI_Model
{


    // public function upload_data($data)
    // {
    //     $this->db->where($this->input->post('id'));
    //     return $this->db->input('tbl_absensi',$data);
  

    // }

}